--- ======================== ---  
                                                                                                                                                                                                          
chance= 1.07                                                                                                       
base=0.00001                                                                                                         
 bethigh = true                                                                                                        
target=balance*1.02                                                                                                
   function dobet()                                                                                                      
chance = 1.07                                                                                                       
  basebet=base                                                                                                        
  if (balance>target) then                                                                                           
   stop()                                                                                                              
  end                                                                                                                
   if win then                                                                                                                
   nextbet = previousbet/1.25
  bethigh = false                                                                                                     
  end                                      
    if not win then                                                                                                      
 nextbet = previousbet+0.0000008                                                                                      
   end                                                      
  end